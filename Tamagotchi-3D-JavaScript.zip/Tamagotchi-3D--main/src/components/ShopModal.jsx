import React, { useState } from 'react';
import { ACCESSORIES_CATALOG, SHELL_THEMES } from '../services/storage';
import { soundFx } from '../audio/soundEffects';
import { X, ShoppingBag, Sparkles, Palette, Check } from 'lucide-react';
export const ShopModal = ({ coins, ownedAccessories, equippedHat, currentThemeId, onBuyAccessory, onEquipHat, onSelectTheme, onClose, }) => {
    const [tab, setTab] = useState('wardrobe');
    return (<div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/75 backdrop-blur-xs">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border-4 border-purple-300 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-purple-500 to-indigo-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-purple-200"/>
            <div>
              <h3 className="font-heading font-bold text-lg leading-tight">Toko &amp; Lemari Aksesoris</h3>
              <p className="text-xs text-purple-200 font-medium">Dompetmu: {coins} 🪙</p>
            </div>
          </div>
          <button onClick={() => {
            soundFx.playBeep();
            onClose();
        }} className="p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors">
            <X className="w-5 h-5"/>
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-purple-100 bg-purple-50/50 p-1.5 gap-1.5">
          <button onClick={() => {
            soundFx.playBeep();
            setTab('wardrobe');
        }} className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${tab === 'wardrobe'
            ? 'bg-purple-600 text-white shadow-xs'
            : 'text-slate-600 hover:bg-purple-100/60'}`}>
            <Sparkles className="w-4 h-4"/> Aksesoris &amp; Topi
          </button>
          <button onClick={() => {
            soundFx.playBeep();
            setTab('themes');
        }} className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${tab === 'themes'
            ? 'bg-purple-600 text-white shadow-xs'
            : 'text-slate-600 hover:bg-purple-100/60'}`}>
            <Palette className="w-4 h-4"/> Cangkang Tamagotchi
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {tab === 'wardrobe' && (<div className="space-y-3">
              {/* Active equipped accessory banner */}
              {equippedHat && (<div className="p-3 rounded-2xl bg-purple-50 border border-purple-200 flex justify-between items-center text-xs shadow-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-purple-200 text-purple-900 flex items-center justify-center text-base">
                      {ACCESSORIES_CATALOG.find((a) => a.id === equippedHat)?.emoji || '🎩'}
                    </div>
                    <div>
                      <span className="text-[10px] uppercase tracking-wider font-extrabold text-purple-600 block">
                        Sedang Dipakai di Hewan:
                      </span>
                      <span className="font-bold text-slate-800 text-xs">
                        {ACCESSORIES_CATALOG.find((a) => a.id === equippedHat)?.name || 'Aksesoris 3D'}
                      </span>
                    </div>
                  </div>
                  <button onClick={() => {
                    onEquipHat(null);
                    soundFx.playBeep();
                }} className="px-3 py-1.5 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl shadow-xs transition-colors">
                    Lepas
                  </button>
                </div>)}

              {ACCESSORIES_CATALOG.map((item) => {
                const isOwned = ownedAccessories.includes(item.id);
                const isEquipped = equippedHat === item.id;
                const canAfford = coins >= item.cost;
                return (<div key={item.id} className={`p-3.5 rounded-2xl border-2 flex items-center justify-between gap-3 ${isEquipped
                        ? 'border-purple-400 bg-purple-50 shadow-xs'
                        : isOwned
                            ? 'border-emerald-200 bg-emerald-50/40'
                            : 'border-slate-200 bg-slate-50'}`}>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-2xl shadow-xs">
                        {item.emoji}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-heading font-bold text-sm text-slate-800">{item.name}</h4>
                          {isEquipped && (<span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-purple-600 text-white">
                              Dipakai
                            </span>)}
                        </div>
                        <p className="text-xs text-slate-500 line-clamp-1">{item.description}</p>
                      </div>
                    </div>

                    <div>
                      {isOwned ? (<button onClick={() => {
                            onEquipHat(isEquipped ? null : item.id);
                        }} className={`btn-tactile px-3.5 py-1.5 font-heading font-bold text-xs rounded-xl flex items-center gap-1 ${isEquipped
                            ? 'bg-purple-100 text-purple-700 hover:bg-purple-200 border border-purple-300'
                            : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-xs'}`}>
                          {isEquipped ? 'Lepas' : <><Check className="w-3.5 h-3.5"/> Pakai</>}
                        </button>) : (<button disabled={!canAfford} onClick={() => onBuyAccessory(item)} className={`btn-tactile px-3 py-1.5 font-heading font-bold text-xs rounded-xl ${canAfford
                            ? 'bg-amber-400 hover:bg-amber-500 text-slate-900 shadow-xs'
                            : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}>
                          Beli {item.cost} 🪙
                        </button>)}
                    </div>
                  </div>);
            })}
            </div>)}

          {tab === 'themes' && (<div className="space-y-3">
              <p className="text-xs text-slate-500">
                Pilih gaya cangkang konsol Tamagotchimu sesuka hati tanpa biaya tambahan!
              </p>
              {SHELL_THEMES.map((theme) => {
                const isSelected = currentThemeId === theme.id;
                return (<button key={theme.id} onClick={() => {
                        onSelectTheme(theme);
                        soundFx.playSelect();
                    }} className={`btn-tactile w-full p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${isSelected
                        ? 'border-purple-500 bg-purple-50 shadow-sm ring-2 ring-purple-300/50'
                        : 'border-slate-200 bg-slate-50 hover:bg-slate-100'}`}>
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${theme.primary} border-2 ${theme.border} shadow-inner`}></div>
                      <div>
                        <div className="font-heading font-bold text-sm text-slate-800">{theme.name}</div>
                        <div className="text-[11px] text-slate-500">Tema Cangkang Konsol</div>
                      </div>
                    </div>
                    {isSelected && (<span className="text-xs font-bold text-purple-600 flex items-center gap-1">
                        <Check className="w-4 h-4"/> Aktif
                      </span>)}
                  </button>);
            })}
            </div>)}
        </div>
      </div>
    </div>);
};
