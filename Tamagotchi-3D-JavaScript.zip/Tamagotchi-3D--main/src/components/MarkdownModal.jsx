import React, { useState, useMemo } from 'react';
import { marked } from 'marked';
import { PET_SPECIES, ACHIEVEMENTS_LIST } from '../services/storage';
import { soundFx } from '../audio/soundEffects';
import { X, BookOpen, Calendar, Award, PenTool, CheckCircle2, Plus, FileText, Sparkles, } from 'lucide-react';
export const MarkdownModal = ({ currentPetId, petName, diary, unlockedAchievements, coins, onAddDiaryEntry, onClaimAchievement, onClose, }) => {
    const [activeTab, setActiveTab] = useState('guide');
    const [isWritingNewEntry, setIsWritingNewEntry] = useState(false);
    const [newTitle, setNewTitle] = useState('');
    const [newContent, setNewContent] = useState('');
    const [previewMode, setPreviewMode] = useState(false);
    // Markdown Care Handbook Content
    const careGuideMarkdown = useMemo(() => {
        const petInfo = PET_SPECIES[currentPetId];
        return `# 📖 Ensiklopedia & Panduan Merawat Pet Virtual 3D

Selamat datang di panduan resmi perawatan hewan kesayanganmu! Rawatlah sahabatmu dengan penuh kasih agar mereka selalu ceria, sehat, dan berkembang.

---

## 🐾 Profil Sahabat Pilihanmu: **${petName}**
* **Spesies**: ${petInfo.species}
* **Karakter Utama**: ${petInfo.nature}
* **Makanan Favorit**: ${petInfo.favoriteFood}
* **Kemampuan Spesial**: ${petInfo.specialSkill}

> *"Setiap hewan peliharaan memiliki kepribadian unik. Elus mereka setiap hari di ruang 3D untuk mempererat ikatan batin!"*

---

## 📊 Memahami 6 Indikator Vital

| Indikator | Fungsi | Cara Meningkatkan |
| :--- | :--- | :--- |
| **🍗 Kenyang** | Energi perut pet | Beri makan biskuit, pelet, salmon segar, atau burger |
| **⚡ Energi** | Tenaga untuk beraktivitas | Matikan lampu & tidurkan pet di kasur empuk |
| **🫧 Kebersihan** | Bebas kuman & bau | Mandikan dengan sabun berbusa di menu Cuci |
| **💖 Kasih Sayang** | Ikatan batin dengan pemilik | Elus di ruang 3D, beri cemilan favorit |
| **😊 Kebahagiaan** | Semangat & keceriaan | Ajak bermain mini-game atau lemparkan bola |
| **🩺 Kesehatan** | Kondisi fisik pet | Jaga kebersihan dan jangan biarkan kelaparan |

---

## 💡 Tips & Trik Bermain

1. **Bermain Mini-Game Rutin**:
   * Tangkap Bintang memberi banyak koin emas dan melatih refleksmu.
   * Tebak Kotak Hadiah memberi kesempatan bonus koin instan jika tebakanmu tepat.
2. **Koleksi Aksesoris & Gaya Cangkang**:
   * Tukarkan koin di Toko untuk membeli Topi Pesta, Mahkota Raja, atau mengubah warna konsol Tamagotchi.
3. **Keamanan Data Offline (100% Aman)**:
   * Game ini **tidak membutuhkan internet**. Seluruh progres, level, koin, dan catatan diary tersimpan langsung di browsermu.
   * Saat kamu menutup game, petmu akan tidur atau bersantai dengan aman tanpa resiko mati mendadak!

---

*Selamat merawat dan bersenang-senang bersama ${petName}!* ✨
`;
    }, [currentPetId, petName]);
    // Insert markdown tag helper for editor
    const insertTag = (prefix, suffix = '') => {
        setNewContent((prev) => `${prev}${prefix}teks${suffix}`);
    };
    const handleSaveDiary = (e) => {
        e.preventDefault();
        if (!newTitle.trim() || !newContent.trim())
            return;
        onAddDiaryEntry(newTitle.trim(), newContent.trim());
        setNewTitle('');
        setNewContent('');
        setIsWritingNewEntry(false);
        setPreviewMode(false);
        soundFx.playLevelUp();
    };
    return (<div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/75 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border-4 border-teal-300 flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-teal-500 to-emerald-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-teal-100"/>
            <div>
              <h3 className="font-heading font-bold text-lg leading-tight">
                Pusat Informasi &amp; Buku Harian
              </h3>
              <p className="text-xs text-teal-100 font-medium">Format rapi dengan Markdown interaktif</p>
            </div>
          </div>
          <button onClick={() => {
            soundFx.playBeep();
            onClose();
        }} className="p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors">
            <X className="w-5 h-5"/>
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-teal-100 bg-teal-50/50 p-1.5 gap-1.5">
          <button onClick={() => {
            soundFx.playBeep();
            setActiveTab('guide');
        }} className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${activeTab === 'guide'
            ? 'bg-teal-600 text-white shadow-xs'
            : 'text-slate-600 hover:bg-teal-100/60'}`}>
            <BookOpen className="w-4 h-4"/> Buku Panduan
          </button>
          <button onClick={() => {
            soundFx.playBeep();
            setActiveTab('diary');
        }} className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${activeTab === 'diary'
            ? 'bg-teal-600 text-white shadow-xs'
            : 'text-slate-600 hover:bg-teal-100/60'}`}>
            <Calendar className="w-4 h-4"/> Buku Harian &amp; Jurnal
          </button>
          <button onClick={() => {
            soundFx.playBeep();
            setActiveTab('achievements');
        }} className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${activeTab === 'achievements'
            ? 'bg-teal-600 text-white shadow-xs'
            : 'text-slate-600 hover:bg-teal-100/60'}`}>
            <Award className="w-4 h-4"/> Prestasi ({unlockedAchievements.length})
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1">
          {/* TAB 1: GUIDE */}
          {activeTab === 'guide' && (<div className="markdown-body text-slate-700 text-sm" dangerouslySetInnerHTML={{
                __html: marked.parse(careGuideMarkdown, { async: false }),
            }}/>)}

          {/* TAB 2: DIARY */}
          {activeTab === 'diary' && (<div className="space-y-4">
              <div className="flex justify-between items-center bg-teal-50 p-3 rounded-2xl border border-teal-200">
                <div>
                  <h4 className="font-heading font-bold text-sm text-teal-900">
                    Catatan Kenangan Bersama {petName}
                  </h4>
                  <p className="text-xs text-teal-700">
                    Tulis jurnal harianmu menggunakan format Markdown yang rapi!
                  </p>
                </div>
                {!isWritingNewEntry && (<button onClick={() => {
                    setIsWritingNewEntry(true);
                    soundFx.playBeep();
                }} className="btn-tactile px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-heading font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-sm">
                    <Plus className="w-4 h-4"/> Tulis Catatan Baru
                  </button>)}
              </div>

              {/* Write New Entry Box */}
              {isWritingNewEntry && (<form onSubmit={handleSaveDiary} className="bg-slate-50 border-2 border-teal-300 rounded-2xl p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      <PenTool className="w-3.5 h-3.5 text-teal-600"/> Tulis Entri Markdown
                    </span>
                    <button type="button" onClick={() => setPreviewMode(!previewMode)} className="text-xs font-bold text-teal-600 hover:text-teal-700 px-2 py-1 rounded-md bg-teal-100">
                      {previewMode ? 'Mode Edit' : 'Pratinjau Markdown'}
                    </button>
                  </div>

                  <input type="text" required placeholder="Judul Catatan (contoh: Hari Pertama Belajar Trik Duduk)" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-teal-400 text-sm font-semibold"/>

                  {/* Markdown Toolbar */}
                  {!previewMode && (<div className="flex flex-wrap gap-1 bg-white p-1.5 rounded-lg border border-slate-200 text-xs font-mono">
                      <button type="button" onClick={() => insertTag('**', '**')} className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 font-bold" title="Tebal">
                        B
                      </button>
                      <button type="button" onClick={() => insertTag('*', '*')} className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 italic" title="Miring">
                        I
                      </button>
                      <button type="button" onClick={() => insertTag('### ')} className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 font-bold" title="Judul Kecil">
                        H3
                      </button>
                      <button type="button" onClick={() => insertTag('- ')} className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200" title="Daftar Titik">
                        • List
                      </button>
                      <button type="button" onClick={() => insertTag('> ')} className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200" title="Kutipan">
                        &ldquo; Kutipan
                      </button>
                    </div>)}

                  {!previewMode ? (<textarea required rows={5} placeholder="Tuliskan pengalaman manismu hari ini... Kamu bisa gunakan **tebal**, *miring*, atau - daftar!" value={newContent} onChange={(e) => setNewContent(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-teal-400 text-sm font-sans"/>) : (<div className="min-h-[120px] p-3 rounded-xl bg-white border border-slate-200 markdown-body text-xs">
                      <div dangerouslySetInnerHTML={{
                        __html: marked.parse(newContent || '*Belum ada isi catatan...*', {
                            async: false,
                        }),
                    }}/>
                    </div>)}

                  <div className="flex justify-end gap-2">
                    <button type="button" onClick={() => {
                    setIsWritingNewEntry(false);
                    setPreviewMode(false);
                }} className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700 font-bold">
                      Batal
                    </button>
                    <button type="submit" className="btn-tactile px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-heading font-bold text-xs rounded-xl shadow-xs">
                      Simpan ke Jurnal 💾
                    </button>
                  </div>
                </form>)}

              {/* Diary Timeline Entries */}
              <div className="space-y-3">
                {diary.length === 0 ? (<p className="text-center py-6 text-slate-400 text-xs">
                    Belum ada catatan jurnal. Tulis sekarang untuk mengenang momen indah!
                  </p>) : (diary.map((entry) => (<div key={entry.id} className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-teal-300 transition-all shadow-xs space-y-2">
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-teal-600 shrink-0"/>
                          <h4 className="font-heading font-bold text-sm text-slate-800">
                            {entry.title}
                          </h4>
                        </div>
                        <span className="text-[11px] font-medium text-slate-400 shrink-0">
                          {entry.dateStr}
                        </span>
                      </div>

                      <div className="markdown-body text-xs text-slate-600 pl-6 border-l-2 border-teal-200" dangerouslySetInnerHTML={{
                    __html: marked.parse(entry.markdownContent, {
                        async: false,
                    }),
                }}/>
                    </div>)))}
              </div>
            </div>)}

          {/* TAB 3: ACHIEVEMENTS */}
          {activeTab === 'achievements' && (<div className="space-y-3">
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex justify-between items-center text-xs">
                <span className="font-bold text-amber-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-500"/> Total Koin Kamu: {coins} 🪙
                </span>
                <span className="font-semibold text-amber-700">
                  Tercapai: {unlockedAchievements.length} / {ACHIEVEMENTS_LIST.length}
                </span>
              </div>

              {ACHIEVEMENTS_LIST.map((ach) => {
                const isUnlocked = unlockedAchievements.includes(ach.id);
                return (<div key={ach.id} className={`p-3.5 rounded-2xl border-2 flex items-center justify-between gap-3 ${isUnlocked
                        ? 'border-emerald-300 bg-emerald-50/50'
                        : 'border-slate-200 bg-slate-50 opacity-70'}`}>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-2xl shadow-xs">
                        {ach.icon}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-heading font-bold text-sm text-slate-800">{ach.title}</h4>
                          {isUnlocked && (<span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-500 text-white flex items-center gap-0.5">
                              <CheckCircle2 className="w-3 h-3"/> Tercapai
                            </span>)}
                        </div>
                        <p className="text-xs text-slate-500">{ach.description}</p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-heading font-bold text-xs text-amber-600 block">
                        +{ach.rewardCoins} 🪙
                      </span>
                    </div>
                  </div>);
            })}
            </div>)}
        </div>
      </div>
    </div>);
};
