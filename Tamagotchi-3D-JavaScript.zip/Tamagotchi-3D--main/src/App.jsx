/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { StorageService, SHELL_THEMES, PET_SPECIES, } from './services/storage';
import { PetScene } from './three/PetScene';
import { soundFx } from './audio/soundEffects';
import { PetHUD } from './components/PetHUD';
import { ActionDock } from './components/ActionDock';
import { PetSelectorModal } from './components/PetSelectorModal';
import { FoodMenuModal } from './components/FoodMenuModal';
import { MiniGameModal } from './components/MiniGameModal';
import { ShopModal } from './components/ShopModal';
import { MarkdownModal } from './components/MarkdownModal';
import { WelcomeBackModal } from './components/WelcomeBackModal';
import { ResetConfirmModal } from './components/ResetConfirmModal';
export default function App() {
    // 1. Initial State from Storage
    const [gameState, setGameState] = useState(() => {
        return StorageService.loadGame().state;
    });
    const [welcomeReport, setWelcomeReport] = useState(null);
    const [toasts, setToasts] = useState([]);
    // Active Modals
    const [showSelector, setShowSelector] = useState(false);
    const [showFoodMenu, setShowFoodMenu] = useState(false);
    const [showMiniGame, setShowMiniGame] = useState(false);
    const [showShop, setShowShop] = useState(false);
    const [showMarkdown, setShowMarkdown] = useState(false);
    const [showResetModal, setShowResetModal] = useState(false);
    const [consoleFrameMode, setConsoleFrameMode] = useState(false); // default to expansive clean viewport!
    // 3D Scene Reference
    const canvasMountRef = useRef(null);
    const petSceneRef = useRef(null);
    // Trigger floating toast feedback
    const showToast = (text, icon = '✨') => {
        const id = Date.now();
        setToasts((prev) => [...prev.slice(-2), { id, text, icon }]);
        setTimeout(() => {
            setToasts((prev) => prev.filter((t) => t.id !== id));
        }, 2800);
    };
    // Check initial load offline report & pet selection
    useEffect(() => {
        const { report } = StorageService.loadGame();
        if (report && report.hasElapsed) {
            setWelcomeReport(report);
        }
        if (!gameState.currentPetId) {
            setShowSelector(true);
        }
    }, []);
    // Current active pet data helper
    const currentPetId = gameState.currentPetId || 'milo';
    const currentPet = gameState.pets[currentPetId];
    // Shell theme helper
    const currentTheme = SHELL_THEMES.find((t) => t.id === gameState.settings.shellThemeId) || SHELL_THEMES[0];
    // Sound state sync
    useEffect(() => {
        soundFx.setEnabled(gameState.settings.soundEnabled);
    }, [gameState.settings.soundEnabled]);
    // Periodic Auto-Save and Stat Decay
    useEffect(() => {
        const interval = setInterval(() => {
            setGameState((prev) => {
                if (!prev.currentPetId || !prev.pets[prev.currentPetId])
                    return prev;
                const pet = { ...prev.pets[prev.currentPetId] };
                // Very gentle real-time natural decay while open (every 30 seconds)
                if (pet.isSleeping) {
                    pet.stats.energy = Math.min(100, pet.stats.energy + 2);
                    pet.stats.hunger = Math.max(20, pet.stats.hunger - 0.3);
                }
                else {
                    pet.stats.hunger = Math.max(15, pet.stats.hunger - 0.5);
                    pet.stats.energy = Math.max(10, pet.stats.energy - 0.3);
                    pet.stats.hygiene = Math.max(15, pet.stats.hygiene - 0.2);
                    pet.stats.happiness = Math.max(15, pet.stats.happiness - 0.2);
                }
                const nextState = {
                    ...prev,
                    pets: {
                        ...prev.pets,
                        [prev.currentPetId]: pet,
                    },
                };
                StorageService.saveGame(nextState);
                return nextState;
            });
        }, 25000);
        return () => clearInterval(interval);
    }, []);
    // Save on state change
    const updateStateAndSave = useCallback((updater) => {
        setGameState((prev) => {
            const next = updater(prev);
            StorageService.saveGame(next);
            return next;
        });
    }, []);
    // 2. Initialize 3D Scene
    useEffect(() => {
        if (!canvasMountRef.current)
            return;
        const scene = new PetScene(canvasMountRef.current, currentPetId, gameState.settings.graphicsQuality);
        petSceneRef.current = scene;
        scene.setPetInteractedCallback(() => {
            handlePetInteraction();
        });
        if (currentPet.equippedHat) {
            scene.updateAccessories(currentPet.equippedHat);
        }
        scene.setSleeping(currentPet.isSleeping);
        return () => {
            scene.dispose();
            petSceneRef.current = null;
        };
    }, []);
    // Re-trigger resize on layout toggle
    useEffect(() => {
        const timer = setTimeout(() => {
            if (petSceneRef.current) {
                petSceneRef.current.onResize();
            }
        }, 50);
        return () => clearTimeout(timer);
    }, [consoleFrameMode]);
    // Handle pet switch in 3D scene
    useEffect(() => {
        if (petSceneRef.current && currentPetId) {
            petSceneRef.current.switchPet(currentPetId);
            petSceneRef.current.updateAccessories(currentPet?.equippedHat || null);
            petSceneRef.current.setSleeping(currentPet?.isSleeping || false);
        }
    }, [currentPetId]);
    // Handle accessory dynamic equip/unequip in 3D scene
    useEffect(() => {
        if (petSceneRef.current) {
            petSceneRef.current.updateAccessories(currentPet?.equippedHat || null);
        }
    }, [currentPet?.equippedHat]);
    // Handle sleeping state change in 3D scene
    useEffect(() => {
        if (petSceneRef.current) {
            petSceneRef.current.setSleeping(currentPet?.isSleeping || false);
        }
    }, [currentPet?.isSleeping]);
    // Handle quality change in 3D scene
    useEffect(() => {
        if (petSceneRef.current) {
            petSceneRef.current.applyQualitySettings(gameState.settings.graphicsQuality);
        }
    }, [gameState.settings.graphicsQuality]);
    // Add XP and check Level Up
    const addXP = (amount) => {
        updateStateAndSave((prev) => {
            if (!prev.currentPetId)
                return prev;
            const pet = { ...prev.pets[prev.currentPetId] };
            pet.xp += amount;
            if (pet.xp >= pet.xpNext) {
                pet.level += 1;
                pet.xp = pet.xp - pet.xpNext;
                pet.xpNext = Math.floor(pet.xpNext * 1.3);
                soundFx.playLevelUp();
                showToast(`Selamat! ${pet.name} naik ke Level ${pet.level}! ⭐`, '🎉');
                // Check level 5 achievement
                if (pet.level >= 5 && !pet.unlockedAchievements.includes('ach_level_5')) {
                    pet.unlockedAchievements = [...pet.unlockedAchievements, 'ach_level_5'];
                    prev.coins += 100;
                    showToast(`Prestasi Tercapai: Tumbuh Bersama! (+100 🪙)`, '🏆');
                }
                // Add auto diary milestone
                const milestoneEntry = {
                    id: `lvl_${Date.now()}`,
                    petId: prev.currentPetId,
                    dateStr: new Date().toLocaleDateString('id-ID', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                    }),
                    timestamp: Date.now(),
                    title: `🌟 ${pet.name} Naik ke Level ${pet.level}!`,
                    markdownContent: `### Hebat Sekali! ${pet.name} Bertambah Pintar! 🎖️\n\nMelalui kasih sayang dan perawatanmu yang telaten, **${pet.name}** berhasil mencapai **Level ${pet.level}**!\n\n* Kapasitas energi dan kebahagiaan bertambah kuat.\n* Teruslah merawat sahabatmu setiap hari!`,
                    isAutoMilestone: true,
                    badge: `Level ${pet.level}`,
                };
                prev.diary = [milestoneEntry, ...prev.diary];
            }
            return {
                ...prev,
                pets: {
                    ...prev.pets,
                    [prev.currentPetId]: pet,
                },
            };
        });
    };
    // 3. User Interactions: Petting
    const handlePetInteraction = () => {
        updateStateAndSave((prev) => {
            if (!prev.currentPetId)
                return prev;
            const pet = { ...prev.pets[prev.currentPetId] };
            pet.stats.love = Math.min(100, pet.stats.love + 5);
            pet.stats.happiness = Math.min(100, pet.stats.happiness + 4);
            return {
                ...prev,
                pets: {
                    ...prev.pets,
                    [prev.currentPetId]: pet,
                },
            };
        });
        addXP(10);
        const petReaction = currentPetId === 'milo'
            ? `${currentPet.name} mengibas ekor dan menjulurkan lidah bahagia!`
            : currentPetId === 'fizzi'
                ? `${currentPet.name} menari indah dan mengibaskan sirip halfmoon-nya!`
                : `${currentPet.name} mendengkur nyaman dan mengusapkan pipinya!`;
        showToast(petReaction, '❤️');
    };
    // Feed Pet
    const handleFeedPet = (food) => {
        if (petSceneRef.current) {
            petSceneRef.current.dropFood(food.emoji);
        }
        updateStateAndSave((prev) => {
            if (!prev.currentPetId)
                return prev;
            const pet = { ...prev.pets[prev.currentPetId] };
            const count = prev.inventory[food.id] || 0;
            if (count <= 0)
                return prev;
            // Apply food stats
            const isFav = food.suitablePet === prev.currentPetId;
            const hungerInc = food.hungerBoost * (isFav ? 1.25 : 1);
            const happyInc = food.happinessBoost * (isFav ? 1.5 : 1);
            pet.stats.hunger = Math.min(100, Math.round(pet.stats.hunger + hungerInc));
            pet.stats.happiness = Math.min(100, Math.round(pet.stats.happiness + happyInc));
            if (food.energyBoost) {
                pet.stats.energy = Math.min(100, pet.stats.energy + food.energyBoost);
            }
            const nextInv = { ...prev.inventory, [food.id]: count - 1 };
            return {
                ...prev,
                inventory: nextInv,
                pets: {
                    ...prev.pets,
                    [prev.currentPetId]: pet,
                },
            };
        });
        addXP(15);
        setShowFoodMenu(false);
        showToast(`Nyam nyam! ${currentPet.name} lahap memakan ${food.name}! (+${food.hungerBoost}% Kenyang)`, food.emoji);
    };
    // Buy Food
    const handleBuyFood = (food) => {
        if (gameState.coins < food.cost)
            return;
        soundFx.playCoin();
        updateStateAndSave((prev) => {
            const curCount = prev.inventory[food.id] || 0;
            return {
                ...prev,
                coins: prev.coins - food.cost,
                inventory: {
                    ...prev.inventory,
                    [food.id]: curCount + 1,
                },
            };
        });
        showToast(`Membeli 1 ${food.name}! Tersisa ${gameState.coins - food.cost} 🪙`, '🛒');
    };
    // Wash / Clean Pet
    const handleWashPet = () => {
        if (petSceneRef.current) {
            petSceneRef.current.triggerWash();
        }
        updateStateAndSave((prev) => {
            if (!prev.currentPetId)
                return prev;
            const pet = { ...prev.pets[prev.currentPetId] };
            pet.stats.hygiene = 100;
            pet.stats.happiness = Math.min(100, pet.stats.happiness + 10);
            // Check clean achievement
            if (!pet.unlockedAchievements.includes('ach_sparkle_clean')) {
                pet.unlockedAchievements = [...pet.unlockedAchievements, 'ach_sparkle_clean'];
                prev.coins += 35;
                showToast('Prestasi Tercapai: Kinclong & Harum! (+35 🪙)', '🏆');
            }
            return {
                ...prev,
                pets: {
                    ...prev.pets,
                    [prev.currentPetId]: pet,
                },
            };
        });
        addXP(20);
        showToast(`Swoosh! ${currentPet.name} sekarang sangat bersih, wangi, dan segar! (100% Bersih)`, '🫧');
    };
    // Toggle Sleep / Awake
    const handleToggleSleep = () => {
        const nextSleep = !currentPet.isSleeping;
        if (petSceneRef.current) {
            petSceneRef.current.setSleeping(nextSleep);
        }
        updateStateAndSave((prev) => {
            if (!prev.currentPetId)
                return prev;
            const pet = { ...prev.pets[prev.currentPetId] };
            pet.isSleeping = nextSleep;
            return {
                ...prev,
                pets: {
                    ...prev.pets,
                    [prev.currentPetId]: pet,
                },
            };
        });
        if (nextSleep) {
            showToast(`Lampu diredupkan... ${currentPet.name} tidur nyenyak memulihkan energi.`, '💤');
        }
        else {
            showToast(`Selamat pagi! ${currentPet.name} terbangun segar bugar!`, '☀️');
        }
    };
    // Mini-Game Reward
    const handleMiniGameReward = (earnedCoins, happinessBoost, gameScore) => {
        updateStateAndSave((prev) => {
            if (!prev.currentPetId)
                return prev;
            const pet = { ...prev.pets[prev.currentPetId] };
            pet.stats.happiness = Math.min(100, pet.stats.happiness + happinessBoost);
            if (gameScore >= 100 && !pet.unlockedAchievements.includes('ach_play_champ')) {
                pet.unlockedAchievements = [...pet.unlockedAchievements, 'ach_play_champ'];
                prev.coins += 75;
                showToast('Prestasi Tercapai: Jagoan Mini-Game! (+75 🪙)', '🏆');
            }
            return {
                ...prev,
                coins: prev.coins + earnedCoins,
                pets: {
                    ...prev.pets,
                    [prev.currentPetId]: pet,
                },
            };
        });
        addXP(30);
        showToast(`Hebat! Bermain bersama ${currentPet.name} mendapat +${earnedCoins} 🪙 & +${happinessBoost}% Kebahagiaan!`, '🎮');
    };
    // Buy Accessory & Auto-Equip onto Pet
    const handleBuyAccessory = (item) => {
        if (gameState.coins < item.cost)
            return;
        soundFx.playCoin();
        soundFx.playSparkle();
        // Auto-equip onto 3D pet immediately
        if (petSceneRef.current) {
            petSceneRef.current.updateAccessories(item.id);
        }
        updateStateAndSave((prev) => {
            if (!prev.currentPetId)
                return prev;
            const pet = { ...prev.pets[prev.currentPetId] };
            pet.equippedHat = item.id;
            pet.equippedAccessory = item.id;
            if (!pet.unlockedAchievements.includes('ach_fashion_star')) {
                pet.unlockedAchievements = [...pet.unlockedAchievements, 'ach_fashion_star'];
                prev.coins += 60;
                showToast('Prestasi Tercapai: Bintang Modis! (+60 🪙)', '🎩');
            }
            return {
                ...prev,
                coins: prev.coins - item.cost,
                ownedAccessories: prev.ownedAccessories.includes(item.id)
                    ? prev.ownedAccessories
                    : [...prev.ownedAccessories, item.id],
                pets: {
                    ...prev.pets,
                    [prev.currentPetId]: pet,
                },
            };
        });
        showToast(`Berhasil membeli & langsung memakaikan ${item.name} ke ${currentPet.name}! ✨`, item.emoji);
    };
    // Equip / Unequip Hat & Accessories
    const handleEquipHat = (hatId) => {
        if (petSceneRef.current) {
            petSceneRef.current.updateAccessories(hatId);
        }
        if (hatId) {
            soundFx.playSparkle();
        }
        else {
            soundFx.playBeep();
        }
        updateStateAndSave((prev) => {
            if (!prev.currentPetId)
                return prev;
            const pet = { ...prev.pets[prev.currentPetId] };
            pet.equippedHat = hatId;
            pet.equippedAccessory = hatId;
            if (hatId && !pet.unlockedAchievements.includes('ach_fashion_star')) {
                pet.unlockedAchievements = [...pet.unlockedAchievements, 'ach_fashion_star'];
                prev.coins += 60;
                showToast('Prestasi Tercapai: Bintang Modis! (+60 🪙)', '🎩');
            }
            return {
                ...prev,
                pets: {
                    ...prev.pets,
                    [prev.currentPetId]: pet,
                },
            };
        });
        showToast(hatId ? `Memakaikan aksesoris baru pada ${currentPet.name}! ✨` : `Melepas aksesoris dari ${currentPet.name}.`, hatId ? '👒' : '🧺');
    };
    // Select Console Shell Theme
    const handleSelectTheme = (theme) => {
        updateStateAndSave((prev) => ({
            ...prev,
            settings: {
                ...prev.settings,
                shellThemeId: theme.id,
            },
        }));
        showToast(`Cangkang konsol diubah ke: ${theme.name}`, '🎨');
    };
    // Sound Toggle
    const handleToggleSound = () => {
        const nextSound = !gameState.settings.soundEnabled;
        soundFx.setEnabled(nextSound);
        if (nextSound)
            soundFx.playBeep();
        updateStateAndSave((prev) => ({
            ...prev,
            settings: {
                ...prev.settings,
                soundEnabled: nextSound,
            },
        }));
        showToast(nextSound ? 'Efek Suara Diaktifkan 🔊' : 'Efek Suara Dimatikan 🔇', '🎵');
    };
    // Cycle Quality
    const handleCycleQuality = () => {
        const sequence = ['low', 'medium', 'high'];
        const curIdx = sequence.indexOf(gameState.settings.graphicsQuality);
        const nextQ = sequence[(curIdx + 1) % sequence.length];
        updateStateAndSave((prev) => ({
            ...prev,
            settings: {
                ...prev.settings,
                graphicsQuality: nextQ,
            },
        }));
        const label = nextQ === 'low' ? 'Hemat Daya (Perangkat Lawas)' : nextQ === 'medium' ? 'Normal' : 'Tinggi (HD)';
        showToast(`Kualitas Grafis: ${label}`, '⚙️');
    };
    // Add Diary Entry (Markdown)
    const handleAddDiaryEntry = (title, content) => {
        const newEntry = {
            id: `diary_${Date.now()}`,
            petId: currentPetId,
            dateStr: new Date().toLocaleDateString('id-ID', {
                day: 'numeric',
                month: 'long',
                year: 'numeric',
            }),
            timestamp: Date.now(),
            title,
            markdownContent: content,
            isAutoMilestone: false,
        };
        updateStateAndSave((prev) => ({
            ...prev,
            diary: [newEntry, ...prev.diary],
        }));
        showToast(`Catatan harian baru disimpan dengan format Markdown!`, '📝');
    };
    // Claim Achievement
    const handleClaimAchievement = (ach) => {
        soundFx.playLevelUp();
        updateStateAndSave((prev) => ({
            ...prev,
            coins: prev.coins + ach.rewardCoins,
        }));
        showToast(`Klaim Hadiah: +${ach.rewardCoins} 🪙`, '🎁');
    };
    // Switch / Select Pet
    const handleSelectPet = (petId, customName) => {
        updateStateAndSave((prev) => {
            const pet = { ...prev.pets[petId] };
            if (customName) {
                pet.name = customName;
            }
            return {
                ...prev,
                currentPetId: petId,
                pets: {
                    ...prev.pets,
                    [petId]: pet,
                },
            };
        });
        // Immediately switch 3D pet and accessories
        if (petSceneRef.current) {
            petSceneRef.current.switchPet(petId);
            petSceneRef.current.updateAccessories(gameState.pets[petId]?.equippedHat || null);
            petSceneRef.current.setSleeping(gameState.pets[petId]?.isSleeping || false);
        }
        setShowSelector(false);
        showToast(`Sekarang bermain bersama ${customName || PET_SPECIES[petId].name}!`, '🐾');
    };
    // Reset Game Handler
    const handleConfirmReset = () => {
        const freshState = StorageService.clearSave();
        setGameState(freshState);
        setShowResetModal(false);
        setShowSelector(true);
        if (petSceneRef.current) {
            petSceneRef.current.switchPet('milo');
            petSceneRef.current.updateAccessories(null);
            petSceneRef.current.setSleeping(false);
        }
        showToast('Permainan Tamagotchi 3D berhasil direset! Silakan pilih hewan barumu.', '🔄');
    };
    // Keyboard Shortcuts (1-6 for actions, Space for pet)
    useEffect(() => {
        const handleKeyDown = (e) => {
            // Don't trigger if user is typing in an input
            if (document.activeElement?.tagName === 'INPUT' ||
                document.activeElement?.tagName === 'TEXTAREA') {
                return;
            }
            if (e.key === '1') {
                soundFx.playBeep();
                setShowFoodMenu(true);
            }
            else if (e.key === '2') {
                handleWashPet();
            }
            else if (e.key === '3') {
                soundFx.playBeep();
                setShowMiniGame(true);
            }
            else if (e.key === '4') {
                handleToggleSleep();
            }
            else if (e.key === '5') {
                soundFx.playBeep();
                setShowShop(true);
            }
            else if (e.key === '6') {
                soundFx.playBeep();
                setShowMarkdown(true);
            }
            else if (e.key === ' ') {
                e.preventDefault();
                handlePetInteraction();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [currentPetId, currentPet]);
    return (<div className="relative w-screen h-screen overflow-hidden bg-slate-950 flex items-center justify-center select-none font-sans">
      {/* Background radial atmosphere */}
      <div className="absolute inset-0 bg-radial from-slate-900 via-slate-950 to-black pointer-events-none"/>

      {/* Floating Toast Feedback Notifications */}
      <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 pointer-events-none flex flex-col items-center gap-1.5 w-full max-w-md px-4">
        {toasts.map((toast) => (<div key={toast.id} className="animate-in fade-in slide-in-from-top-4 duration-300 px-4 py-2 rounded-2xl bg-slate-900/95 border border-amber-400/60 text-slate-100 shadow-2xl backdrop-blur-md text-xs sm:text-sm font-heading font-bold flex items-center gap-2 text-center">
            <span className="text-base">{toast.icon}</span>
            <span>{toast.text}</span>
          </div>))}
      </div>

      {/* 3D WebGL Canvas Layer - Persistent & Permanent */}
      <div className="absolute inset-0 w-full h-full z-0 overflow-hidden">
        <div ref={canvasMountRef} className="w-full h-full cursor-grab active:cursor-grabbing" title="Ketuk atau elus hewan peliharaanmu!"/>
      </div>

      {/* Decorative Console Bezel Frame Overlay (When consoleFrameMode is active) */}
      {consoleFrameMode && (<div className="pointer-events-none fixed inset-0 z-10 flex items-center justify-center p-2 sm:p-5">
          <div className={`w-full h-full max-w-4xl max-h-[92vh] rounded-[36px] sm:rounded-[48px] border-8 sm:border-[12px] ${currentTheme.border} shadow-2xl flex flex-col justify-between p-3 sm:p-4 bg-transparent ring-8 ring-black/40`}>
            {/* Header Branding Pill */}
            <div className="self-center px-4 py-1 rounded-full bg-slate-900/85 border border-slate-700/80 text-white flex items-center gap-2 shadow-md">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-heading font-extrabold text-xs uppercase tracking-wider text-amber-300">
                TAMAGOTCHI 3D • {currentPet.name}
              </span>
            </div>

            {/* Bottom Retro Speaker Grille Indicator */}
            <div className="self-center flex gap-1.5 opacity-60 pb-1">
              {[0, 1, 2, 3, 4, 5].map((i) => (<div key={i} className="w-1.5 h-1.5 rounded-full bg-slate-400"/>))}
            </div>
          </div>
        </div>)}

      {/* HUD Header Overlay (Fixed on Top) */}
      <PetHUD pet={currentPet} coins={gameState.coins} soundEnabled={gameState.settings.soundEnabled} quality={gameState.settings.graphicsQuality} isSleeping={currentPet.isSleeping} consoleFrameMode={consoleFrameMode} onToggleSound={handleToggleSound} onCycleQuality={handleCycleQuality} onToggleFrameMode={() => setConsoleFrameMode(!consoleFrameMode)} onOpenSelector={() => setShowSelector(true)} onOpenMarkdown={() => setShowMarkdown(true)} onResetGame={() => setShowResetModal(true)}/>

      {/* Action Dock (Fixed at Bottom) */}
      <ActionDock isSleeping={currentPet.isSleeping} onFeedClick={() => setShowFoodMenu(true)} onWashClick={handleWashPet} onPlayClick={() => setShowMiniGame(true)} onToggleSleep={handleToggleSleep} onShopClick={() => setShowShop(true)} onMarkdownClick={() => setShowMarkdown(true)} onPetClick={handlePetInteraction}/>

      {/* MODALS */}
      {/* 1. Pet Selector Modal */}
      {showSelector && (<PetSelectorModal currentPetId={gameState.currentPetId} onSelectPet={handleSelectPet} canClose={gameState.currentPetId !== null} onClose={() => setShowSelector(false)}/>)}

      {/* 2. Food & Feeding Modal */}
      {showFoodMenu && (<FoodMenuModal petId={currentPetId} petName={currentPet.name} inventory={gameState.inventory} coins={gameState.coins} onFeed={handleFeedPet} onBuyFood={handleBuyFood} onClose={() => setShowFoodMenu(false)}/>)}

      {/* 3. Mini-Game Modal */}
      {showMiniGame && (<MiniGameModal petId={currentPetId} petName={currentPet.name} onClose={() => setShowMiniGame(false)} onReward={handleMiniGameReward}/>)}

      {/* 4. Shop & Wardrobe Modal */}
      {showShop && (<ShopModal coins={gameState.coins} ownedAccessories={gameState.ownedAccessories} equippedHat={currentPet.equippedHat} currentThemeId={gameState.settings.shellThemeId} onBuyAccessory={handleBuyAccessory} onEquipHat={handleEquipHat} onSelectTheme={handleSelectTheme} onClose={() => setShowShop(false)}/>)}

      {/* 5. Markdown Handbook & Live Diary Modal */}
      {showMarkdown && (<MarkdownModal currentPetId={currentPetId} petName={currentPet.name} diary={gameState.diary} unlockedAchievements={currentPet.unlockedAchievements} coins={gameState.coins} onAddDiaryEntry={handleAddDiaryEntry} onClaimAchievement={handleClaimAchievement} onClose={() => setShowMarkdown(false)}/>)}

      {/* 6. Welcome Back Offline Report Modal */}
      {welcomeReport && (<WelcomeBackModal report={welcomeReport} onClose={() => setWelcomeReport(null)}/>)}

      {/* 7. Reset Game Confirmation Modal */}
      {showResetModal && (<ResetConfirmModal petName={currentPet.name} onConfirm={handleConfirmReset} onCancel={() => setShowResetModal(false)}/>)}
    </div>);
}
