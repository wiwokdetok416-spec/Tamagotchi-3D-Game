/**
 * 100% Offline Procedural Sound Effects via Web Audio API.
 * Zero external files, zero latency, lightweight and battery-friendly.
 */
class SoundManager {
    constructor() {
        this.ctx = null;
        this.enabled = true;
        // AudioContext will be lazily initialized on first user interaction
    }
    setEnabled(val) {
        this.enabled = val;
    }
    isEnabled() {
        return this.enabled;
    }
    getContext() {
        if (!this.enabled)
            return null;
        if (!this.ctx && typeof window !== 'undefined') {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (AudioCtx) {
                this.ctx = new AudioCtx();
            }
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume().catch(() => { });
        }
        return this.ctx;
    }
    // Classic Tamagotchi 8-bit UI beep
    playBeep(freq = 880, duration = 0.08) {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'square';
            osc.frequency.setValueAtTime(freq, ctx.currentTime);
            gain.gain.setValueAtTime(0.08, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + duration);
        }
        catch {
            // Audio fallback safe
        }
    }
    // Happy button / positive select
    playSelect() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(523.25, now); // C5
            osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.08); // E5
            gain.gain.setValueAtTime(0.1, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(now + 0.12);
        }
        catch { }
    }
    // Pet barking (Milo)
    playBark() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const now = ctx.currentTime;
            // First yip
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(440, now);
            osc.frequency.exponentialRampToValueAtTime(700, now + 0.06);
            osc.frequency.exponentialRampToValueAtTime(320, now + 0.16);
            gain.gain.setValueAtTime(0.12, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.16);
            // Follow-up baby bark
            setTimeout(() => {
                if (!this.enabled || !this.ctx)
                    return;
                const n2 = this.ctx.currentTime;
                const o2 = this.ctx.createOscillator();
                const g2 = this.ctx.createGain();
                o2.type = 'sawtooth';
                o2.frequency.setValueAtTime(480, n2);
                o2.frequency.exponentialRampToValueAtTime(780, n2 + 0.05);
                o2.frequency.exponentialRampToValueAtTime(340, n2 + 0.14);
                g2.gain.setValueAtTime(0.1, n2);
                g2.gain.exponentialRampToValueAtTime(0.001, n2 + 0.14);
                o2.connect(g2);
                g2.connect(this.ctx.destination);
                o2.start(n2);
                o2.stop(n2 + 0.14);
            }, 90);
        }
        catch { }
    }
    // Cat Meow / Purr (Ngkur)
    playMeow() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(550, now);
            osc.frequency.linearRampToValueAtTime(750, now + 0.12);
            osc.frequency.exponentialRampToValueAtTime(450, now + 0.28);
            gain.gain.setValueAtTime(0.08, now);
            gain.gain.linearRampToValueAtTime(0.12, now + 0.1);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.28);
        }
        catch { }
    }
    // Water bubble pop (Fizzi)
    playBubble() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(400, now);
            osc.frequency.exponentialRampToValueAtTime(1200, now + 0.08);
            gain.gain.setValueAtTime(0.12, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.09);
        }
        catch { }
    }
    // Eating munch crunch
    playEat() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            [0, 0.08, 0.16].forEach((delay, i) => {
                setTimeout(() => {
                    if (!this.enabled || !this.ctx)
                        return;
                    const now = this.ctx.currentTime;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(260 + i * 40, now);
                    osc.frequency.exponentialRampToValueAtTime(140, now + 0.05);
                    gain.gain.setValueAtTime(0.15, now);
                    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
                    osc.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc.start(now);
                    osc.stop(now + 0.05);
                }, delay * 1000);
            });
        }
        catch { }
    }
    // Cleaning bubble sparkles
    playSparkle() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const freqs = [784, 988, 1175, 1568];
            freqs.forEach((f, idx) => {
                setTimeout(() => {
                    if (!this.enabled || !this.ctx)
                        return;
                    const now = this.ctx.currentTime;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(f, now);
                    gain.gain.setValueAtTime(0.08, now);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
                    osc.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc.start(now);
                    osc.stop(now + 0.1);
                }, idx * 45);
            });
        }
        catch { }
    }
    // Level up fanfare
    playLevelUp() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const notes = [440, 554.37, 659.25, 880];
            notes.forEach((f, i) => {
                setTimeout(() => {
                    if (!this.enabled || !this.ctx)
                        return;
                    const now = this.ctx.currentTime;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = i === 3 ? 'square' : 'triangle';
                    osc.frequency.setValueAtTime(f, now);
                    gain.gain.setValueAtTime(0.12, now);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + (i === 3 ? 0.4 : 0.12));
                    osc.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc.start(now);
                    osc.stop(now + (i === 3 ? 0.4 : 0.12));
                }, i * 110);
            });
        }
        catch { }
    }
    // Coin collect
    playCoin() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(987.77, now); // B5
            osc.frequency.setValueAtTime(1318.51, now + 0.08); // E6
            gain.gain.setValueAtTime(0.1, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.25);
        }
        catch { }
    }
    // Love / Petting chime
    playLove() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(659.25, now);
            osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
            gain.gain.setValueAtTime(0.09, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.22);
        }
        catch { }
    }
    // Sleep lullaby notes
    playSleep() {
        const ctx = this.getContext();
        if (!ctx)
            return;
        try {
            const notes = [523.25, 493.88, 440, 392];
            notes.forEach((f, idx) => {
                setTimeout(() => {
                    if (!this.enabled || !this.ctx)
                        return;
                    const now = this.ctx.currentTime;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(f, now);
                    gain.gain.setValueAtTime(0.07, now);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
                    osc.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc.start(now);
                    osc.stop(now + 0.35);
                }, idx * 160);
            });
        }
        catch { }
    }
}
export const soundFx = new SoundManager();
